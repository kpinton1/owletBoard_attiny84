ArduinoNunchuk - Improved Wii Nunchuk library for Arduino

Copyright 2011-2013 Gabriel Bianconi, http://www.gabrielbianconi.com/

Project URL: http://www.gabrielbianconi.com/projects/arduinonunchuk/

Based on the following resources:
 - http://www.windmeadow.com/node/42
 - http://todbot.com/blog/2008/02/18/wiichuck-wii-nunchuck-adapter-available/
 - http://wiibrew.org/wiki/Wiimote/Extension_Controllers


INSTALLATION:

Copy the 'ArduinoNunchuk' folder, located in the same folder as this 'README' file, to the Arduino libraries folder (Arduino/libraries).